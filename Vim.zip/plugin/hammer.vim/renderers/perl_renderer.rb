command File.join(Hammer::ENV.commands_path, "pod.pl"), /pl|pm/
